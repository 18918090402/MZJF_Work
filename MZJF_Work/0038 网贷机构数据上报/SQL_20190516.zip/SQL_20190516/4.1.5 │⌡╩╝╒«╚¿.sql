
--4.1.5 ��ʼծȨ

set mapreduce.job.name = pdw_report_05_creditor; 
set mapreduce.job.queuename = etl-dw;  
set hive.exec.parallel = true ;
set hive.groupby.skewindata = true ;
set hive.map.aggr = true ; 
set hive.enforce.bucketing = true;
set hive.exec.dynamic.partition = true;
set hive.exec.dynamic.partition.mode = nonstrict; 
set hive.exec.max.dynamic.partitions.pernode = 100000000;
set hive.exec.max.dynamic.partitions = 100000000;
set hive.exec.max.created.files = 100000000;




        insert overwrite table pdw.report_05_creditor
        SELECT ""                                                                        as version,              --�ӿڰ汾��
               "CERT20190411026"                                                         as sourceCode,           --ƽ̨���
               t.id                                                                      as finClaimId,           --��ʼծȨ���
               t.bo_id                                                                   as sourceProductCode,    --ɢ����Ϣ���
               certIdcardHash(ui.id_num)                                                 as userIdcardHash,       --�����û�֤����hashֵ
               printf("%.2f", t.price * 1.0)                                             as invAmount,            --������(Ԫ)
               printf("%.6f", coalesce(bp.bp_rate_lender, bo.bo_rate) / 100 * 1.0)       as invRate,              --����Ԥ���껯����
               t.create_time                                                             as invTime,              --�����Ϣʱ��
               printf("%.2f", 0 * 1.0)                                                   as redpackage,           --����������������Ԫ��
               t.create_time                                                             as lockTime,             --������ֹʱ��
               ""                                                                        as batchnum,             --���κ�
               ""                                                                        as sendtime              --����ʱ��
          FROM odsopr.debt_exchange_account_20190430 t 
     LEFT JOIN idw.fact_borrows bo
            ON t.bo_id = bo.bo_id
     left join odsopr.borrows_prepare bp
            on bo.bp_id = bp.id
     left join (
                    SELECT owner_id as user_id,
                           id_card as id_num
                      from ods.t_acc_p2p_hist 
               ) ui 
            on ui.user_id = t.user_id
         where t.price > 0 
           and t.bank_flag = 1         --���
           and t.status in (1, 2, 3)   --1:������ 2��ծת�� 3��������
;


