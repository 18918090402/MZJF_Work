--4.1.12 Ͷ����ϸ

set mapreduce.job.name = pdw_report_12_lendparticulars; 
set mapreduce.job.queuename = etl-dw;  
set hive.exec.parallel = true ;
set hive.groupby.skewindata = true ;
set hive.map.aggr = true ; 
set hive.enforce.bucketing = true;
set hive.exec.dynamic.partition = true;
set hive.exec.dynamic.partition.mode = nonstrict; 
set hive.exec.max.dynamic.partitions.pernode = 100000000;
set hive.exec.max.dynamic.partitions = 100000000;
set hive.exec.max.created.files = 100000000;



      insert overwrite table pdw.report_12_lendparticulars
      select t.* ,
             row_number() over(order by t.sourceFinancingCode) id,
             "1" batch_type
      from (        
      --�ƻ���
      select ""                                                  as version,             --�ӿڰ汾��
             "CERT20190411026"                                   as sourceCode,          --ƽ̨���
             isa.trans_id                                        as transId,             --��������������ˮ��
             concat("FP", cast(fp.id as string))                 as sourceFinancingCode, --��Ʒ��Ϣ���
             "2"                                                 as transType,           --��������
             printf("%.2f", t.price*1.0)                         as transMoney,          --���׽�Ԫ��
             certIdcardHash(coalesce(ui.id_num, uh.id_num))      as userIdcardHash,      --��������֤���� hash ֵ
             t.create_time                                       as transTime,           --���׷���ʱ��
             ""                                                  as batchnum,
             ""                                                  as sendtime
        from msc.tmp_debt_exchange_account_20190430 t 
   left join odsopr.invt_seri_auth_link isa
          on isa.seri_no = t.seri_no 
   left join (
                    SELECT owner_id as user_id,
                           id_card as id_num
                      from odsopr.acc_p2p_reportbak20190610
                     where account_type = "user" 
             ) ui 
          on ui.user_id = t.user_id 
   left join (
                  SELECT id,
                         regexp_extract(regexp_replace(id_num, ' ', ''), '^[\s\n\t]*([0-9]+[xX]?)[_\-]?[0-9]?[\s\n\t]*$', 1) id_num
                    FROM odsopr.user_info_reportbak20190610
             ) uh
          on t.user_id = uh.id                               
   left join odsopr.vip_account va 
          on va.id = t.va_id 
   left join odsopr.finance_plan fp 
          on fp.id = va.fp_id 
       where t.va_id > 0 
         
         union all 
      
      select ""                                                   as version,             --�ӿڰ汾��
             "CERT20190411026"                                    as sourceCode,          --ƽ̨���
             isa.trans_id                                         as transId,             --��������������ˮ��
             concat("NN", cast(bo.id as string))                  as sourceFinancingCode, --��Ʒ��Ϣ���
             "2"                                                  as transType,           --��������
             printf("%.2f", t.price*1.0)                          as transMoney,          --���׽�Ԫ��
             certIdcardHash(coalesce(ui.id_num, uh.id_num))       as userIdcardHash,      --��������֤���� hash ֵ
             t.create_time                                        as transTime,           --���׷���ʱ��
             ""                                                   as batchnum,
             ""                                                   as sendtime
        from msc.tmp_debt_exchange_account_20190430 t 
   left join odsopr.invt_seri_auth_link isa 
          on isa.seri_no = t.seri_no    
   left join (
                    SELECT owner_id as user_id,
                           id_card as id_num
                      from odsopr.acc_p2p_reportbak20190610
                     where account_type = "user" 
             ) ui 
          on ui.user_id = t.user_id
   left join (
                  SELECT id,
                         regexp_extract(regexp_replace(id_num, ' ', ''), '^[\s\n\t]*([0-9]+[xX]?)[_\-]?[0-9]?[\s\n\t]*$', 1) id_num
                    FROM odsopr.user_info_reportbak20190610
             ) uh
          on t.user_id = uh.id                               
   left join odsopr.borrows_reportbak20190610 bo 
          on bo.id = t.bo_id
       where t.va_id = 0 
       
       
) t ;


