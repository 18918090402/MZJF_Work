--4.1.9 ������ˮ
set mapreduce.job.name = pdw_report_09_transact; 
set mapreduce.job.queuename = etl-dw;  
set hive.exec.parallel = true ;
set hive.groupby.skewindata = true ;
set hive.map.aggr = true ; 
set hive.enforce.bucketing = true;
set hive.exec.dynamic.partition = true;
set hive.exec.dynamic.partition.mode = nonstrict; 
set hive.exec.max.dynamic.partitions.pernode = 100000000;
set hive.exec.max.dynamic.partitions = 100000000;
set hive.exec.max.created.files = 100000000;




      insert overwrite table pdw.report_09_transact 
      select t.* ,
             row_number() over(order by t.userIdcardHash) id,
             "1" batch_type
      from ( 
      
      
      --2-����
      select ""                                                  as version,             --�ӿڰ汾��
             "CERT20190411026"                                   as sourceCode,          --ƽ̨���
             isa.trans_id                                        as transId,             --��������������ˮ��
             t.bo_id                                             as sourceProductCode,   --ɢ����Ϣ���
             concat(bpc.loan_use_name,                           
                    "��",                                        
                    bo_finish_price,                             
                    "Ԫ")                                        as sourceProductName,   --ɢ������
             t.id                                                as finClaimId,          --ծȨ���
             -1                                                  as transferId,          --ת����Ϣ���
             -1                                                  as replanId,            --����ƻ����
             "2"                                                 as transType,           --��������
             printf("%.2f", t.price * 1.0)                       as transMoney,          --���׽�Ԫ��
             certIdcardHash(coalesce(ui.id_num, uh.id_num))      as userIdcardHash,      --��������֤����hash ֵ
             t.create_time                                       as transTime,           --���׷���ʱ��
             ""                                                  as batchnum,            --���κ�
             ""                                                  as sendtime             --����ʱ��
        from msc.tmp_debt_exchange_account_20190430 t 
   left join odsopr.invt_seri_auth_link isa
          on isa.seri_no = t.seri_no
   left join (
                    SELECT owner_id as user_id,
                           id_card as id_num
                      from odsopr.acc_p2p_reportbak20190610
                     where account_type = "user" 
             ) ui 
          on ui.user_id = t.user_id
   left join (
                  SELECT id,
                         regexp_extract(regexp_replace(id_num, ' ', ''), '^[\s\n\t]*([0-9]+[xX]?)[_\-]?[0-9]?[\s\n\t]*$', 1) id_num
                    FROM odsopr.user_info_reportbak20190610
             ) uh
          on t.user_id = uh.id
   left join (
                  select bo_id, bo_purpose, 
                         cast(cast(bo_finish_price as decimal(38,2)) as string) bo_finish_price
                    from idw.fact_borrows 
             ) bo 
          on bo.bo_id = t.bo_id 
   left join msc.bo_purpose_category bpc          --"�����;"�衰����Ԫ
          on bpc.bo_purpose = bo.bo_purpose
       
       union all 
             
      --1-�ſ�
      select ""                                                as version,
             "CERT20190411026"                                 as sourceCode,
             concat(cast(br.bo_id as string), '_1')            as transId,
             br.bo_id                                          as sourceProductCode,
             concat(bpc.loan_use_name,                         
                    "��",                                      
                    bo_finish_price,                          
                    "Ԫ")                                      as sourceProductName,   --ɢ������
             -1                                                as finClaimId,
             -1                                                as transferId,
             -1                                                as replanId,
             "1"                                               as transType,
             printf("%.2f", br.br_price_b * 1.0)               as transMoney,
             certIdcardHash(coalesce(ui.id_num, uh.id_num))    as userIdcardHash,
             br.create_time                                    as transTime,           --��ȷ��
             ""                                                as batchnum,            --���κ�
             ""                                                as sendtime             --����ʱ��
        from (
                  select  br.bo_id                                          
                         ,sum(br.br_price) br_price
                         ,sum(br.price_return) price_return
                         ,sum(br.br_price_b) br_price_b
                         ,sum(br.br_price_l) br_price_l
                         ,max(br.create_time) create_time
                    from odsopr.borrows_repayment_reportbak20190610 br 
                   where ( br.br_repay_time is null or to_date(br.br_repay_time) > '2019-06-10' )
                     --and exists(select 1 from msc.tmp_debt_exchange_account_20190430 t where t.bo_id = br.bo_id) 
                     and exists(select 1 from pdw.report_02_scatterinvest t where cast(t.sourceProductCode as bigint) = br.bo_id) 
                group by br.bo_id
             ) br 
   left join (
                  select bo_id, bo_purpose, user_id, bo_success_time,
                         cast(cast(bo_finish_price as decimal(38,2)) as string) bo_finish_price
                    from idw.fact_borrows 
             ) bo 
          on bo.bo_id = br.bo_id 
   left join msc.bo_purpose_category bpc          --"�����;"�衰����Ԫ
          on bpc.bo_purpose = bo.bo_purpose
   left join (
                    SELECT owner_id as user_id,
                           id_card as id_num
                      from odsopr.acc_p2p_reportbak20190610
                     where account_type = "user" 
             ) ui 
          on ui.user_id = bo.user_id
   left join (
                  SELECT id,
                         regexp_extract(regexp_replace(id_num, ' ', ''), '^[\s\n\t]*([0-9]+[xX]?)[_\-]?[0-9]?[\s\n\t]*$', 1) id_num
                    FROM odsopr.user_info_reportbak20190610
             ) uh
          on bo.user_id = uh.id    
    
    union all 
       
      --4-�������
      select ""                                                                              as version,
             "CERT20190411026"                                                               as sourceCode,
             concat(cast(br.bo_id as string), '_4')                                          as transId, 
             br.bo_id                                                                        as sourceProductCode,
             concat(bpc.loan_use_name,                                                       
                    "��",                                                                    
                    bo_finish_price,                                                         
                    "Ԫ")                                                                    as sourceProductName,   --ɢ������
             -1                                                                              as finClaimId,
             -1                                                                              as transferId,
             -1                                                                              as replanId,
             "4"                                                                             as transType,
             printf("%.2f", (br.br_price+br.price_return-br.br_price_b-br.br_price_l) * 1.0) as transMoney,      
             certIdcardHash(coalesce(ui.id_num, uh.id_num))                                  as userIdcardHash,
             create_time                                                                     as transTime, 
             ""                                                                              as batchnum,            --���κ�
             ""                                                                              as sendtime             --����ʱ��             
        from (
                  select  br.bo_id                                          
                         ,sum(br.br_price) br_price
                         ,sum(br.price_return) price_return
                         ,sum(br.br_price_b) br_price_b
                         ,sum(br.br_price_l) br_price_l
                         ,max(br.create_time) create_time
                    from odsopr.borrows_repayment_reportbak20190610 br 
                   where ( br.br_repay_time is null or to_date(br.br_repay_time) > '2019-06-10' )
                     --and exists(select 1 from msc.tmp_debt_exchange_account_20190430 t where t.bo_id = br.bo_id) 
                     and exists(select 1 from pdw.report_02_scatterinvest t where cast(t.sourceProductCode as bigint) = br.bo_id)
                group by br.bo_id        
             ) br 
   left join (
                  select bo_id, bo_purpose, user_id, bo_success_time,
                         cast(cast(bo_finish_price as decimal(38,2)) as string) bo_finish_price
                    from idw.fact_borrows 
             ) bo 
          on bo.bo_id = br.bo_id 
   left join msc.bo_purpose_category bpc          --"�����;"�衰����Ԫ
          on bpc.bo_purpose = bo.bo_purpose
   left join (
                    SELECT owner_id as user_id,
                           id_card as id_num
                      from odsopr.acc_p2p_reportbak20190610
                     where account_type = "user" 
             ) ui 
          on ui.user_id = bo.user_id
   left join (
                  SELECT id,
                         regexp_extract(regexp_replace(id_num, ' ', ''), '^[\s\n\t]*([0-9]+[xX]?)[_\-]?[0-9]?[\s\n\t]*$', 1) id_num
                    FROM odsopr.user_info_reportbak20190610
             ) uh
          on bo.user_id = uh.id     
    
    union all 
    
    --37-����-δ�黹
      select "" as version,
             "CERT20190411026" as sourceCode,
             br.br_id as transId,
             br.bo_id as sourceProductCode,
             concat(bpc.loan_use_name,                                                       
                    "��",                                                                    
                    bo_finish_price,                                                         
                    "Ԫ") as sourceProductName,
             -1 as finClaimId,
             -1 as transferId,
             -1 as replanId,
             "37" as transType,
             printf("%.2f", br.br_price_b * 1.0) as transMoney,
             certIdcardHash(coalesce(ui.id_num, uh.id_num)) as userIdcardHash,
             br.compensate_time as transTime,
             "" as batchnum,
             "" as sendtime
        from (
                  select * from idw.fact_borrows_repayment br
                   where br.br_transfer_fa_id > 0 
                     and (br.br_is_repay = 0 or to_date(br.br_repay_time) > '2019-06-10') 
                     and not exists(select 1 from msc.tmp_history_debt b where b.id = br.br_id)
             ) br 
   left join (
                select bo_id, bo_purpose, user_id, bo_success_time,
                       cast(cast(bo_finish_price as decimal(38,2)) as string) bo_finish_price
                  from idw.fact_borrows 
             ) bo 
          on bo.bo_id = br.bo_id
   left join msc.bo_purpose_category bpc          --"�����;"�衰����Ԫ
          on bpc.bo_purpose = bo.bo_purpose
   left join (
                    SELECT owner_id as user_id,
                           id_card as id_num
                      from odsopr.acc_p2p_reportbak20190610
                     where account_type = "user" 
             ) ui 
          on ui.user_id = bo.user_id
   left join (
                  SELECT id,
                         regexp_extract(regexp_replace(id_num, ' ', ''), '^[\s\n\t]*([0-9]+[xX]?)[_\-]?[0-9]?[\s\n\t]*$', 1) id_num
                    FROM odsopr.user_info_reportbak20190610
             ) uh
          on bo.user_id = uh.id                 
       where exists( select 1 from pdw.report_02_scatterinvest z where z.sourceProductCode = cast(br.bo_id as string) )    --�������ϱ���ɢ��һ��  �޳�AMC
       
       
       ) t 
     where t.transMoney <> '0.00'
      ;
    






    
--  select    820060538.7 - 638036130.33 ;    --182024408.37
    
    
 --�����ָ���������AMC��
    drop view if exists msc.tmp_history_debt ;
    
    create view msc.tmp_history_debt
    as 
    select t.id 
    from odsopr.borrows_repayment t 
    join ( 
           select distinct t.bo_id, t.plan_time 
             from odsopr.invt_history_debt_info t 
            where t.is_transfer = 1 
              and to_date(t.update_time) <= '2019-06-10'
              and not exists(select 1 from idw.amc_bo a where a.bo_id = t.bo_id) 
         ) b 
    on b.bo_id = t.bo_id 
    and b.plan_time = t.br_time 
    ; 


