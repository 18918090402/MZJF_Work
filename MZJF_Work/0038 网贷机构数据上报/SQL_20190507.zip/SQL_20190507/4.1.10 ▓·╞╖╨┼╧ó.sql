--4.1.10 ��Ʒ��Ϣ  
set mapreduce.job.name = pdw_report_10_lendproduct; 
set mapreduce.job.queuename = etl-dw;  
set hive.exec.parallel = true ;
set hive.groupby.skewindata = true ;
set hive.map.aggr = true ; 
set hive.enforce.bucketing = true;
set hive.exec.dynamic.partition = true;
set hive.exec.dynamic.partition.mode = nonstrict; 
set hive.exec.max.dynamic.partitions.pernode = 100000000;
set hive.exec.max.dynamic.partitions = 100000000;
set hive.exec.max.created.files = 100000000;




      insert overwrite table pdw.report_10_lendproduct
      --�ƻ���
      select ""                                 as version,
             "CERT20190411026"                  as sourceCode,
             fp.id                              as sourceFinancingCode,
             fp.publish_date                    as financingStartTime,
             fp.title                           as productName,
             cast(fp.rate_min as decimal(38,6)) as rate,
             cast(fp.rate_min as decimal(38,6)) as minRate,
             cast(fp.rate_max as decimal(38,6)) as maxRate,
             case when fp.expect_unit = 0 then fp.expect * 30 else fp.expect end as term,
             ""                                 as batchnum,
             ""                                 as sendtime
        from odsopr.finance_plan fp
  inner join odsopr.vip_account va 
          on va.fp_id = fp.id
  inner join odsopr.debt_exchange_account_20190430 t 
          on va.id = t.va_id
         and t.price > 0 
         and t.bank_flag = 1 
         and t.va_id > 0
        
        union all 
        
      --ŵŵӯ
      select ""                                       as version,
             "CERT20190411026"                        as sourceCode,
             bo.id                                    as sourceFinancingCode,
             bo.publish_time                          as financingStartTime,
             concat("ŵŵӯ", 
                    cast(bo.id as string))            as productName,
             cast(bp.bp_rate_lender as decimal(38,6)) as rate,
             cast(bp.bp_rate_lender as decimal(38,6)) as minRate,
             cast(bp.bp_rate_lender as decimal(38,6)) as maxRate,
             case when bo.bo_expect_cat = 2 then bo.bo_expect * 30 else bo.bo_expect end as term,
             ""                                       as batchnum,
             ""                                       as sendtime             
        from odsopr.borrows bo 
   left join odsopr.borrows_prepare bp
          on bo.bp_id = bp.id
  inner join odsopr.debt_exchange_account_20190430 t 
          on bo.id = t.bo_id
         and t.price > 0 
         and t.bank_flag = 1 
         and t.va_id = 0
   ;
   
   