--4.1.9 ������ˮ
set mapreduce.job.name = pdw_report_09_transact; 
set mapreduce.job.queuename = etl-dw;  
set hive.exec.parallel = true ;
set hive.groupby.skewindata = true ;
set hive.map.aggr = true ; 
set hive.enforce.bucketing = true;
set hive.exec.dynamic.partition = true;
set hive.exec.dynamic.partition.mode = nonstrict; 
set hive.exec.max.dynamic.partitions.pernode = 100000000;
set hive.exec.max.dynamic.partitions = 100000000;
set hive.exec.max.created.files = 100000000;




      insert overwrite table pdw.report_09_transact
      --2-����
      select ""                             as version,             --�ӿڰ汾��
             "CERT20190411026"              as sourceCode,          --ƽ̨���
             isa.trans_id                   as transId,             --��������������ˮ��
             t.bo_id                        as sourceProductCode,   --ɢ����Ϣ���
             concat(bpc.loan_use_name,
                    "��",
                    bo_finish_price,
                    "Ԫ")                   as sourceProductName,   --ɢ������
             t.id                           as finClaimId,          --ծȨ���
             -1                             as transferId,          --ת����Ϣ���
             -1                             as replanId,            --����ƻ����
             "2-����"                       as transType,           --��������
             cast(t.price as decimal(38,2)) as transMoney,          --���׽�Ԫ��
             certIdcardHash(ui.id_num)      as userIdcardHash,      --��������֤����hash ֵ
             t.create_time                  as transTime,           --���׷���ʱ��
             ""                             as batchnum,            --���κ�
             ""                             as sendtime             --����ʱ��
        from odsopr.debt_exchange_account_20190430 t 
   left join odsopr.invt_seri_auth_link isa
          on isa.seri_no = t.seri_no
   left join (
                    SELECT owner_id as user_id,
                           id_card as id_num
                      from ods.t_acc_p2p_hist 
             ) ui 
          on ui.user_id = t.user_id
   left join (
                  select bo_id, bo_purpose, 
                         cast(cast(bo_finish_price as decimal(38,2)) as string) bo_finish_price
                    from idw.fact_borrows 
             ) bo 
          on bo.bo_id = t.bo_id 
   left join msc.bo_purpose_category bpc          --"�����;"�衰����Ԫ
          on bpc.bo_purpose = bo.bo_purpose   
       where t.price > 0 
         and t.bank_flag = 1      --���
       
       union all 
             
      --1-�ſ�
      select ""                                          as version,
             "CERT20190411026"                           as sourceCode,
             br.id                                       as transId,             -- ?? ��ȷ��
             br.bo_id                                    as sourceProductCode,
             concat(bpc.loan_use_name,                   
                    "��",                                
                    bo_finish_price,                     
                    "Ԫ")                                as sourceProductName,   --ɢ������
             -1                                          as finClaimId,
             -1                                          as transferId,
             br.id                                       as replanId,
             "1-�ſ�"                                    as transType,
             cast(br.br_price_b as decimal(38,2))        as transMoney,
             certIdcardHash(ui.id_num)                   as userIdcardHash,
             br.create_time                              as transTime,           --??��ȷ��
             ""                                          as batchnum,            --���κ�
             ""                                          as sendtime             --����ʱ��
        from odsopr.borrows_repayment br 
   left join (
                  select bo_id, bo_purpose, user_id, bo_success_time,
                         cast(cast(bo_finish_price as decimal(38,2)) as string) bo_finish_price
                    from idw.fact_borrows 
             ) bo 
          on bo.bo_id = br.bo_id 
   left join msc.bo_purpose_category bpc          --"�����;"�衰����Ԫ
          on bpc.bo_purpose = bo.bo_purpose
   left join (
                    SELECT owner_id as user_id,
                           id_card as id_num
                      from ods.t_acc_p2p_hist 
             ) ui 
          on ui.user_id = bo.user_id
       where br.br_repay_time is null 
         and exists(select 1 from odsopr.debt_exchange_account_20190430 t where t.price > 0 and t.bank_flag = 1 and t.bo_id = br.bo_id) 
    
    union all 
       
      --4-�������
      select ""                                                                              as version,
             "CERT20190411026"                                                               as sourceCode,
             br.id                                                                           as transId,             -- ?? ��ȷ��
             br.bo_id                                                                        as sourceProductCode,
             concat(bpc.loan_use_name,                                                       
                    "��",                                                                    
                    bo_finish_price,                                                         
                    "Ԫ")                                                                    as sourceProductName,   --ɢ������
             -1                                                                              as finClaimId,
             -1                                                                              as transferId,
             br.id                                                                           as replanId,
             "4-�������"                                                                  as transType,
             cast(br.br_price+br.price_return-br.br_price_b-br.br_price_l  as decimal(38,2)) as transMoney,          --?? ��ȷ��
             certIdcardHash(ui.id_num)                                                       as userIdcardHash,
             br.br_time                                                                      as transTime,           --?? ��ȷ��
             ""                                                                              as batchnum,            --���κ�
             ""                                                                              as sendtime             --����ʱ��             
        from odsopr.borrows_repayment br 
   left join (
                  select bo_id, bo_purpose, user_id, bo_success_time,
                         cast(cast(bo_finish_price as decimal(38,2)) as string) bo_finish_price
                    from idw.fact_borrows 
             ) bo 
          on bo.bo_id = br.bo_id 
   left join msc.bo_purpose_category bpc          --"�����;"�衰����Ԫ
          on bpc.bo_purpose = bo.bo_purpose
   left join (
                    SELECT owner_id as user_id,
                           id_card as id_num
                      from ods.t_acc_p2p_hist 
             ) ui 
          on ui.user_id = bo.user_id
       where br.br_repay_time is null
         and exists(select 1 from odsopr.debt_exchange_account_20190430 t where t.price > 0 and t.bank_flag = 1 and t.bo_id = br.bo_id) 
    
    union all 
    
    --����-δ�黹
      select "" as version,
             "CERT20190411026" as sourceCode,
             t.id as transId,  
             t.bo_id as sourceProductCode,
             concat(bpc.loan_use_name,                                                       
                    "��",                                                                    
                    bo_finish_price,                                                         
                    "Ԫ") as sourceProductName,
             -1 as finClaimId,
             -1 as transferId, 
             -1 as replanId,
             "37-�������C����ƽ̨����" as transType,
             cast(t.bg_price as decimal(38,2)) as transMoney, 
             certIdcardHash(ui.id_num) as userIdcardHash,
             t.bg_time as transTime,
             "" as batchnum,
             "" as sendtime
        from odsopr.borrows_guarantee t
   left join (
                  select bo_id, bo_purpose, user_id, bo_success_time,
                         cast(cast(bo_finish_price as decimal(38,2)) as string) bo_finish_price
                    from idw.fact_borrows 
             ) bo 
          on bo.bo_id = t.bo_id
   left join msc.bo_purpose_category bpc          --"�����;"�衰����Ԫ
          on bpc.bo_purpose = bo.bo_purpose
   left join (
                    SELECT owner_id as user_id,
                           id_card as id_num
                      from ods.t_acc_p2p_hist 
             ) ui 
          on ui.user_id = t.user_id          
       where t.bg_returned_time is null
         and not exists(select 1 from msc.tmp_history_debt b where b.id = t.br_id)
    ;
    
    
    
    
    
    
 --ȷ�� ?? 
    create view msc.tmp_history_debt
    as 
    select t.id from odsopr.borrows_repayment t 
    inner join ( select distinct bo_id, plan_time from odsopr.invt_history_debt_info where is_transfer = 1 ) b 
    on b.bo_id = t.bo_id 
    and b.plan_time = t.br_time  ;
    